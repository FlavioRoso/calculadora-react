self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "5cd8725e5744958211db791ce82e727a",
    "url": "/index.html"
  },
  {
    "revision": "baaf4c88ce94b88e69b2",
    "url": "/static/css/main.72513202.chunk.css"
  },
  {
    "revision": "bdbf4a82a8595bc30bb3",
    "url": "/static/js/2.ccb36bf3.chunk.js"
  },
  {
    "revision": "e88a3e95b5364d46e95b35ae8c0dc27d",
    "url": "/static/js/2.ccb36bf3.chunk.js.LICENSE.txt"
  },
  {
    "revision": "baaf4c88ce94b88e69b2",
    "url": "/static/js/main.b0c99faf.chunk.js"
  },
  {
    "revision": "e54719769ab0f2288bbb",
    "url": "/static/js/runtime-main.5757a36a.js"
  }
]);